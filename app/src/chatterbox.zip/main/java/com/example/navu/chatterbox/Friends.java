package com.example.navu.chatterbox;

/**
 * Created by Navu on 09-May-18.
 */

class Friends {

    public  String data;

    public  Friends(){

    }

    public Friends(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
